"use strict";
exports.id = 481;
exports.ids = [481];
exports.modules = {

/***/ 9481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7561);
/* harmony import */ var next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);





const Leftbar = (classWitdraw, c2, c3, c4)=>{
    console.log(classWitdraw);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-b39d4d4dc4840995" + " " + "left-container",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-b39d4d4dc4840995" + " " + "left-container-header",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "pad--s",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3",
                                children: "Tu Saldo:"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3 left-flex-container-h",
                                children: [
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/icons/currency-usd-g.png",
                                        className: "jsx-b39d4d4dc4840995" + " " + "dollar--svg"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "jsx-b39d4d4dc4840995" + " " + "fontw-l",
                                        children: " 120.00"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: "/extra",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/icons/right-arrow-svg.svg",
                            className: "jsx-b39d4d4dc4840995" + " " + "right-arrow--svg"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-b39d4d4dc4840995" + " " + "left-container-body",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "/play",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "jsx-b39d4d4dc4840995" + " " + (classWitdraw.c2 || ""),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/icons/controller-classic-l.png",
                                        alt: "home",
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-img left-img-active"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3 left-h3-active",
                                        children: "JUEGA"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "/profile",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "jsx-b39d4d4dc4840995" + " " + (classWitdraw.c4 || ""),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/icons/account-l.png",
                                        alt: "home",
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-img left-img-active"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3  left-h3-active",
                                        children: "PERFIL"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "/deposit",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "jsx-b39d4d4dc4840995" + " " + (classWitdraw.c3 || ""),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/icons/cash-fast-l.png",
                                        alt: "home",
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-img left-img-active"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3 left-h3-active",
                                        children: "DEPOSITO"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "/withdraw",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "jsx-b39d4d4dc4840995" + " " + (classWitdraw.classWitdraw || ""),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/icons/currency-usd-l.png",
                                        alt: "home",
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-img left-img-active"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3 left-h3-active",
                                        children: "RETIRO"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item disable",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            href: "../../pages/solo/solo.html",
                            className: "jsx-b39d4d4dc4840995",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "icons/alert-outline-l.png",
                                    alt: "home",
                                    className: "jsx-b39d4d4dc4840995" + " " + "left-container-img"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3",
                                    children: "SOPORTE"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-b39d4d4dc4840995" + " " + "left-container-body-item disable",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            href: "../../pages/solo/solo.html",
                            className: "jsx-b39d4d4dc4840995",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "icons/help-box-l.png",
                                    alt: "home",
                                    className: "jsx-b39d4d4dc4840995" + " " + "left-container-img"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "jsx-b39d4d4dc4840995" + " " + "left-container-h3",
                                    children: "TUTORIAL"
                                })
                            ]
                        })
                    })
                ]
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "b39d4d4dc4840995",
                children: ".dollar--svg.jsx-b39d4d4dc4840995{height:25px}.right-arrow--svg.jsx-b39d4d4dc4840995{height:18px;-webkit-filter:invert(100%)sepia(19%)saturate(6900%)hue-rotate(23deg)brightness(98%)contrast(108%);filter:invert(100%)sepia(19%)saturate(6900%)hue-rotate(23deg)brightness(98%)contrast(108%);padding-right:10px;-webkit-align-self:center;-ms-flex-item-align:center;align-self:center;cursor:pointer}.left-flex-container-h.jsx-b39d4d4dc4840995{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;gap:10px}.disable.jsx-b39d4d4dc4840995{pointer-events:none}.left-container.jsx-b39d4d4dc4840995{background-color:#081325;border-right:1px solid#3c5376!important;-moz-box-shadow:inset 0 -1px hsl(0deg 0%100%/10%),8px 0 16px -4px rgb(0 0 0/75%);box-shadow:inset 0 -1px hsl(0deg 0%100%/10%),8px 0 16px -4px rgb(0 0 0/75%);-webkit-box-shadow:inset 0 -1px hsl(0deg 0%100%/10%),8px 0 16px -4px rgb(0 0 0/75%);position:relative;z-index:4}.interface.jsx-b39d4d4dc4840995{min-height:62.5rem;background-color:rgba(22,23,36,1);background-image:url(https://assets.gamersclub.com.br/csgo-frontend/static/media/Background.9db68e3a.png);background-position:center top;-webkit-background-size:100%;-moz-background-size:100%;-o-background-size:100%;background-size:100%;background-repeat:no-repeat;overflow:auto}.left-container-header.jsx-b39d4d4dc4840995{background:#171f30;border-bottom:1px solid#3c5376;padding-top:15px;padding-bottom:15px;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-moz-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.pad--s.jsx-b39d4d4dc4840995{padding:1rem 3rem 1rem 1.5rem}.fontw-l.jsx-b39d4d4dc4840995{font-weight:lighter}.left-container-body-item.jsx-b39d4d4dc4840995{padding-left:.7rem;padding-right:1rem;padding-top:.8rem;padding-bottom:.8rem}.left-container-body-item.jsx-b39d4d4dc4840995 a.jsx-b39d4d4dc4840995{padding:.7rem 1rem;-webkit-border-radius:20px;-moz-border-radius:20px;border-radius:20px}.left-container-body-item.jsx-b39d4d4dc4840995:hover .left-container-body-anchor.jsx-b39d4d4dc4840995{background-color:#3c5376}.left-container-body-item.jsx-b39d4d4dc4840995:hover .left-container-h3.jsx-b39d4d4dc4840995{color:#fff}.left-body-anchor-active.jsx-b39d4d4dc4840995{background-color:#3c5376}.left-body-anchor-active.jsx-b39d4d4dc4840995 .left-h3-active.jsx-b39d4d4dc4840995{color:#fff!important}.left-body-anchor-active.jsx-b39d4d4dc4840995 .left-img-active.jsx-b39d4d4dc4840995{filter:brightness(0%)invert(100%);-webkit-filter:brightness(0%)invert(100%);-moz-filter:brightness(0%)invert(100%)}.left-container-body-item.jsx-b39d4d4dc4840995:hover .left-container-img.jsx-b39d4d4dc4840995{filter:brightness(0%)invert(100%);-webkit-filter:brightness(0%)invert(100%);-moz-filter:brightness(0%)invert(100%)}.left-container-h3.jsx-b39d4d4dc4840995{font-size:14px;font-weight:400;color:rgb(146,162,190);margin-top:2px}.left-container-body-item.jsx-b39d4d4dc4840995 a.jsx-b39d4d4dc4840995{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;gap:10px}.bottom-icon.jsx-b39d4d4dc4840995{position:absolute;bottom:5px}.bottom-icon.jsx-b39d4d4dc4840995 img.jsx-b39d4d4dc4840995{height:30px}@media screen and (max-width:767px){.left-container.jsx-b39d4d4dc4840995{display:none}}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Leftbar);


/***/ })

};
;